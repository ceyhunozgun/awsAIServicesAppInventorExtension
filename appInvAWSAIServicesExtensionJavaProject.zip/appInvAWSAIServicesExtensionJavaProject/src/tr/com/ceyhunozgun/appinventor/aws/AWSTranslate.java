// -*- mode: java; c-basic-offset: 2; -*-
// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2014 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package tr.com.ceyhunozgun.appinventor.aws;

import android.app.Activity;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.handlers.AsyncHandler;
import com.amazonaws.regions.Region;
import com.amazonaws.services.translate.AmazonTranslateAsyncClient;
import com.amazonaws.services.translate.model.TranslateTextRequest;
import com.amazonaws.services.translate.model.TranslateTextResult;
import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.ErrorMessages;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * AWS Translate component for translation.
 *
 * @author ceyhun.ozgun@gmail.com (Ceyhun OZGUN)
 */
@DesignerComponent(version = 1,
    description = "Language translation component that uses Amazon Translate. ",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/control.png")
@UsesPermissions(permissionNames = "android.permission.INTERNET")
@SimpleObject(external=true)
@UsesLibraries(libraries = "aws-polly-translate-rekognition-all.jar")
public final class AWSTranslate extends AWSNonvisibleComponent
{
  private String sourceLanguage = "en";
  private String targetLanguage = "tr";

  public AWSTranslate(ComponentContainer container) {
    super(container.$form());

  }

  @SimpleProperty(description = "The code of the source language.  Supported languages are: " +
          "English (en)\n," +
          "Spanish (es)\n" +
          "Turkish (tr)\n" +
          "French (fr)\n" +
          "German (de)\n" +
          "Italian (it).")
  public String SourceLanguage() {
    return sourceLanguage;
  }

  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_STRING, defaultValue = "en")
  @SimpleProperty
  public void SourceLanguage(String language) {
    this.sourceLanguage = language;
  }

  @SimpleProperty(description = "The code of the target language.  Supported languages are: " +
          "English (en)\n," +
          "Spanish (es)\n" +
          "Turkish (tr)\n" +
          "French (fr)\n" +
          "German (de)\n" +
          "Italian (it).")
  public String TargetLanguage() {
    return sourceLanguage;
  }

  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_STRING, defaultValue = "tr")
  @SimpleProperty
  public void TargetLanguage(String language) {
    this.targetLanguage = language;
  }

  @SimpleFunction(description = "Translates the text from source language to target language. " +
          "Translation is done from English to another language or from another language to English. " +
          "Translation is done asynchronously and the \"TextTranslated\" event is triggered.")
  public void Translate(final String text) {
    getCredentials(new Runnable()
       {
         @Override
         public void run()
         {
            AsynchUtil.runAsynchronously(new Runnable()
            {
              @Override
              public void run()
              {
                try
                {
                  performRequest(text);
                }
                catch (Exception e)
                {
                  StringWriter sw = new StringWriter();
                  PrintWriter pw = new PrintWriter(sw);
                  e.printStackTrace(pw);
                  pw.flush();
                  form.dispatchErrorOccurredEvent(AWSTranslate.this, "Translate",
                          ErrorMessages.ERROR_EXTENSION_ERROR, 1, e.toString(), sw.toString());
                }
              }
            });
         }
       });
  }

  @SimpleEvent(description = "Triggered when Amazon Translate service returns the " +
          "translated text. If an error occurs, error is returned.")
  public void TextTranslated(String error, String translatedText) {
    EventDispatcher.dispatchEvent(this, "TextTranslated", error, translatedText);
  }

  private void performRequest(final String text) throws Exception
  {
    AmazonTranslateAsyncClient translateAsyncClient = new AmazonTranslateAsyncClient(new BasicAWSCredentials(awsAccessKeyId, awsSecretKey));
    translateAsyncClient.setRegion(Region.getRegion(region));

    TranslateTextRequest request = new TranslateTextRequest()
            .withText(text)
            .withSourceLanguageCode(sourceLanguage)
            .withTargetLanguageCode(targetLanguage);
    translateAsyncClient.translateTextAsync(request, new AsyncHandler<TranslateTextRequest, TranslateTextResult>()
    {
      @Override
      public void onError(final Exception e)
      {
        // Dispatch the event.
        activity.runOnUiThread(new Runnable() {
          @Override
          public void run() {
            TextTranslated(e.toString(), "");
          }
        });
      }

      @Override
      public void onSuccess(TranslateTextRequest request, final TranslateTextResult translateTextResult)
      {
        // Dispatch the event.
        activity.runOnUiThread(new Runnable() {
          @Override
          public void run() {
            TextTranslated("", translateTextResult.getTranslatedText());
          }
        });
      }
    });
  }
}
