README file for AWS AI Services AppInventor Extension

This file lists the required commands to build the AIX file. 

1. Download App Inventor 2 sources.
git clone  https://github.com/mit-cml/appinventor-sources.git

Follow the steps until it is built with ant command.
More information can be found at http://appinventor.mit.edu/appinventor-sources/

2. Copy Java Source files from this project to components/src folder. (Copy src dir to appinventor-sources/appinventor/components folder)

3. Generate AWS SDK Fat jar that contains AWS SDK. 
cd awsSdkFatJar
mvn package

4. Copy jar file (target/aws-polly-translate-rekognition-all.jar) to appinventor-sources/appinventor/lib/ceyhunozgun folder (after generating ceyhunozgun dir)

5. Add jar to build file (appinventor-sources/appinventor/components/build.xml) as shown below

Go to last child of <target name="CopyComponentLibraries"
Add the line below to the target
    <copy toFile="${public.deps.dir}/aws-polly-translate-rekognition-all.jar" file="${lib.dir}/ceyhunozgun/aws-polly-translate-rekognition-all.jar" /> 

after lines shown below.

    <!-- Add extension libraries here -->
    <!-- Example: <copy toFile"${public.deps.dir}/my-dependency.jar" file="${lib.dir}/my-dependency/my-dependency-1.0.0.jar" /> -->
    <!-- Remember to include my-dependency.jar in the @UsesLibraries annotation in the extension -->

Please note that the target name and position can change if AppInventor project modify the build.xml file. Place it accordingly if it is modified

6. Build the extension with 
ant extensions
command at appinventor-sources/appinventor/ folder. 
tr.com.ceyhunozgun.appinventor.aws.aix file should be generated in appinventor-sources/appinventor/components/build/extensions folder

Good luck.


