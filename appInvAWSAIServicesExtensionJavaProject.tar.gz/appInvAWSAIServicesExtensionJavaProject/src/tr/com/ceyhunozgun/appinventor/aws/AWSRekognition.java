// -*- mode: java; c-basic-offset: 2; -*-
/// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2012 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package tr.com.ceyhunozgun.appinventor.aws;

import android.app.Activity;
import android.text.TextUtils;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.internal.StaticCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.services.polly.AmazonPollyPresigningClient;
import com.amazonaws.services.polly.model.OutputFormat;
import com.amazonaws.services.polly.model.SynthesizeSpeechPresignRequest;
import com.amazonaws.services.rekognition.AmazonRekognitionClient;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.util.IOUtils;
import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.util.*;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

/**
 * Imave processing component that uses AWS Rekognition.
 *
 * @author ceyhun.ozgun@gmail.com (Ceyhun OZGUN)
 */
@DesignerComponent(version = 1,
    description = "Image analysis component that uses Amazon Rekognition. " +
            "It can detect objects and text in images.",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/camera.png")
@UsesPermissions(permissionNames = "android.permission.INTERNET")
@SimpleObject(external=true)
@UsesLibraries(libraries = "aws-polly-translate-rekognition-all.jar")
public class AWSRekognition extends AWSNonvisibleComponent
{

  public AWSRekognition(ComponentContainer container) {
    super(container.$form());
  }

  @SimpleFunction(description = "Detects text in the image. After text is detected, \"TextDetected\" event is triggered.")
  public void DetectText(final String image) {
    getCredentials(new Runnable()
    {
      @Override
      public void run()
      {
        AsynchUtil.runAsynchronously(new Runnable()
        {
          @Override
          public void run()
          {
            InputStream inputStream = null;
            try
            {
              AmazonRekognitionClient rekognition = new AmazonRekognitionClient(new BasicAWSCredentials(awsAccessKeyId, awsSecretKey));
              rekognition.setRegion(Region.getRegion(region));

              inputStream = MediaUtil.openMedia(form, image);
              ByteBuffer imageBytes = ByteBuffer.wrap(IOUtils.toByteArray(inputStream));

              DetectTextRequest req = new DetectTextRequest()
                      .withImage(new Image().withBytes(imageBytes));
              DetectTextResult res = rekognition.detectText(req);
              List<TextDetection> labels = res.getTextDetections();

              String ret = "";
              if (labels != null && labels.size() > 0)
              {
                for (TextDetection td : labels)
                {
                  if (td.getType().equals("LINE"))
                    ret += td.getDetectedText() + "\n";
                }
              }
              final String text = ret;
              activity.runOnUiThread(new Runnable()
              {
                @Override
                public void run()
                {
                  TextDetected("", text);
                }
              });
            }
            catch (final AmazonServiceException e) {
              activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  TextDetected(e.toString(), "");
                }
              });
            }
            catch (Exception e)
            {
              StringWriter sw = new StringWriter();
              PrintWriter pw = new PrintWriter(sw);
              e.printStackTrace(pw);
              pw.flush();
              form.dispatchErrorOccurredEvent(AWSRekognition.this, "DetectText",
                      ErrorMessages.ERROR_EXTENSION_ERROR, 1, e.toString(), sw.toString());
            }
            finally
            {
              if (inputStream != null) {
                try
                {
                  inputStream.close();
                }
                catch (IOException e)
                {
                }
              }
            }
          }
        });
      }
    });
  }

  @SimpleFunction(description = "Detects objects and scene in the image. After detection, \"LabelsDetected\" event is triggered.")
  public void DetectLabels(final String image) {
    getCredentials(new Runnable()
    {
      @Override
      public void run()
      {
        AsynchUtil.runAsynchronously(new Runnable()
        {
          @Override
          public void run()
          {
            InputStream inputStream = null;

            try
            {
              AmazonRekognitionClient rekognition = new AmazonRekognitionClient(new BasicAWSCredentials(awsAccessKeyId, awsSecretKey));
              rekognition.setRegion(Region.getRegion(region));

              inputStream = MediaUtil.openMedia(form, image);
              ByteBuffer imageBytes = ByteBuffer.wrap(IOUtils.toByteArray(inputStream));

              DetectLabelsRequest req = new DetectLabelsRequest()
                      .withImage(new Image().withBytes(imageBytes))
                      .withMaxLabels(3)
                      .withMinConfidence(85F);
              DetectLabelsResult res = rekognition.detectLabels(req);
              List<Label> labels = res.getLabels();
              String lbls = "";
              if (labels != null && labels.size() > 0)
              {
                for (int i = 0; i < labels.size(); i++)
                {
                  Label l = labels.get(i);
                  if (i > 0)
                    lbls += ", ";
                  lbls += l.getName();
                }
              }
              final String finalLbls = lbls;
              activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  LabelsDetected("", finalLbls);
                }
              });
            }
            catch (final AmazonServiceException e)
            {
              activity.runOnUiThread(new Runnable() {
                @Override
                public void run() { LabelsDetected(e.toString(), ""); }
              });
            }
            catch (Exception e)
            {
              StringWriter sw = new StringWriter();
              PrintWriter pw = new PrintWriter(sw);
              e.printStackTrace(pw);
              pw.flush();
              form.dispatchErrorOccurredEvent(AWSRekognition.this, "DetectLabels",
                      ErrorMessages.ERROR_EXTENSION_ERROR, 1, e.toString(), sw.toString());
            }
            finally
            {
              if (inputStream != null) {
                try
                {
                  inputStream.close();
                }
                catch (IOException e)
                {
                }
              }
            }
          }
          });
      }
    });
  }


  @SimpleEvent(description = "Triggered when Amazon Rekognition returned the " +
          "detected text. If an error occurs, error is returned.")
  public void TextDetected(String error, String text) {
    EventDispatcher.dispatchEvent(this, "TextDetected", error, text);
  }

  @SimpleEvent(description = "Triggered when Amazon Rekognition returned the " +
          "detected labels. If an error occurs, error is returned.")
  public void LabelsDetected(String error, String labels) {
    EventDispatcher.dispatchEvent(this, "LabelsDetected", error, labels);
  }
}
