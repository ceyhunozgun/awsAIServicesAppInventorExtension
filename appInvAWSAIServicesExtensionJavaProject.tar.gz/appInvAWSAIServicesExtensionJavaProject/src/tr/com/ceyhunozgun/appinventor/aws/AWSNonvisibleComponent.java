// -*- mode: java; c-basic-offset: 2; -*-
/// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2012 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package tr.com.ceyhunozgun.appinventor.aws;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;

@SimpleObject(external=true)
public class AWSNonvisibleComponent extends AndroidNonvisibleComponent
{
  static final String PREFEERENCES_NAME = "tr.com.ceyhunozgun.appinventor.aws";

  protected String awsAccessKeyId;
  protected String awsSecretKey;
  protected String region;

  protected final Activity activity;

  public AWSNonvisibleComponent(ComponentContainer container) {
    super(container.$form());
    activity = container.$context();
  }

  @SimpleFunction(description = "Clears the saved credentials.")
  public void ClearCredentials() {
    SharedPreferences prefs = form.getSharedPreferences(PREFEERENCES_NAME, Context.MODE_PRIVATE);

    SharedPreferences.Editor editor = prefs.edit();

    editor.clear();
    editor.commit();
  }

  @SimpleFunction(description = "Shows the saved credentials.")
  public void ShowCredentials() {
    loadCredentials();
    showCredentials(null);
  }

  private void showCredentials(final Runnable handler)
  {
    AlertDialog.Builder builder = new AlertDialog.Builder(form);
    builder.setTitle("Please enter your AWS Credentials");

    LinearLayout layout = new LinearLayout(form);

    layout.setOrientation(LAYOUT_ORIENTATION_VERTICAL);

    final EditText accessKeyInput = createTextField("Access Key Id");
    accessKeyInput.setText(awsAccessKeyId);
    layout.addView(accessKeyInput);

    final EditText secretKeyInput = createTextField("Secret Key");
    secretKeyInput.setText(awsSecretKey);
    layout.addView(secretKeyInput);

    final EditText regionInput = createTextField("Region");
    regionInput.setText(region);
    layout.addView(regionInput);

    builder.setView(layout);
    builder.setPositiveButton("OK", null);

    final AlertDialog alertDialog = builder.create();
    alertDialog.setOnShowListener(new DialogInterface.OnShowListener()
    {
      @Override
      public void onShow(DialogInterface dialog)
      {
        Button button = ((AlertDialog) dialog).getButton(AlertDialog.BUTTON_POSITIVE);
        button.setOnClickListener(new View.OnClickListener()
        {
          @Override
          public void onClick(View view)
          {
            awsAccessKeyId = accessKeyInput.getText().toString();
            if (awsAccessKeyId == null || awsAccessKeyId.equals(""))
            {
              showMessage("Please enter Access Key Id", new Runnable()
              {
                @Override
                public void run()
                {
                  accessKeyInput.requestFocus();
                }
              });
              return;
            }
            awsSecretKey = secretKeyInput.getText().toString();
            if (awsSecretKey == null || awsSecretKey.equals(""))
            {
              showMessage("Please enter Secret Key", new Runnable()
              {
                @Override
                public void run()
                {
                  secretKeyInput.requestFocus();
                }
              });
              return;
            }
            region = regionInput.getText().toString();
            if (region == null || region.equals(""))
            {
              showMessage("Please enter Region", new Runnable()
              {
                @Override
                public void run()
                {
                  regionInput.requestFocus();
                }
              });
              return;
            }
            saveCredentials();
            alertDialog.dismiss();
            if (handler != null)
              handler.run();
          }
        });
      }

      private void showMessage(String message, final Runnable closeHandler)
      {
        AlertDialog dialog = new AlertDialog.Builder(alertDialog.getContext())
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener()
                {
                  @Override
                  public void onClick(DialogInterface dialogInterface, int i)
                  {
                    closeHandler.run();
                  }
                })
                .create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener()
        {
          @Override
          public void onDismiss(DialogInterface dialogInterface)
          {
            closeHandler.run();
          }
        });
        dialog.show();
      }
    });
    alertDialog.show();
  }

  protected void getCredentials(final Runnable handler)
  {
    if (loadCredentials())
      handler.run();
    else
      showCredentials(handler);
  }

  private boolean loadCredentials()
  {
    SharedPreferences prefs = form.getSharedPreferences(PREFEERENCES_NAME, Context.MODE_PRIVATE);

    awsAccessKeyId = prefs.getString("awsAccessKeyId", "");
    awsSecretKey = prefs.getString("awsSecretKey", "");
    region = prefs.getString("region", "");

    return !awsAccessKeyId.equals("");
  }
  private void saveCredentials()
  {
    SharedPreferences prefs = form.getSharedPreferences(PREFEERENCES_NAME, Context.MODE_PRIVATE);

    SharedPreferences.Editor editor = prefs.edit();

    editor.putString("awsAccessKeyId", awsAccessKeyId);
    editor.putString("awsSecretKey", awsSecretKey);
    editor.putString("region", region);

    editor.commit();
  }

  private EditText createTextField(String hint)
  {
    final EditText accessKeyInput = new EditText(form);
    accessKeyInput.setHint(hint);
    accessKeyInput.setInputType(InputType.TYPE_CLASS_TEXT);
    return accessKeyInput;
  }
}
