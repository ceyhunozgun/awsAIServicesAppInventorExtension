// -*- mode: java; c-basic-offset: 2; -*-
/// Copyright 2009-2011 Google, All Rights reserved
// Copyright 2011-2012 MIT, All rights reserved
// Released under the Apache License, Version 2.0
// http://www.apache.org/licenses/LICENSE-2.0

package tr.com.ceyhunozgun.appinventor.aws;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.internal.StaticCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.services.polly.AmazonPollyClient;
import com.amazonaws.services.polly.AmazonPollyPresigningClient;
import com.amazonaws.services.polly.model.OutputFormat;
import com.amazonaws.services.polly.model.SynthesizeSpeechRequest;
import com.amazonaws.services.polly.model.SynthesizeSpeechResult;
import com.amazonaws.util.IOUtils;
import com.google.appinventor.components.annotations.*;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.common.PropertyTypeConstants;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.collect.Maps;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import com.google.appinventor.components.runtime.util.ErrorMessages;
import com.google.appinventor.components.runtime.util.FileUtil;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Text To Speech component that uses AWS Polly.
 *
 * @author ceyhun.ozgun@gmail.com (Ceyhun OZGUN)
 */
@DesignerComponent(version = 1,
    description = "Text To Speech component that uses Amazon Polly. " +
            "The audio is produced asynchronously and \"AudioIsReady\" event is triggered.",
    category = ComponentCategory.EXTENSION,
    nonVisible = true,
    iconName = "images/soundEffect.png")
@UsesPermissions(permissionNames = "android.permission.INTERNET")
@SimpleObject(external=true)
@UsesLibraries(libraries = "aws-polly-translate-rekognition-all.jar")
public class AWSPolly extends AWSNonvisibleComponent
{
  private String language = "en";

  private static final Map<String, String> mimeTypeToExtension;
  private static final Map<String, String> voicesByLang;


  public AWSPolly(ComponentContainer container) {
    super(container.$form());
  }

  @SimpleProperty(description = "The code of the language.  Supported languages are: " +
          "English (en)\n," +
          "Spanish (es)\n" +
          "Turkish (tr)\n" +
          "French (fr)\n" +
          "German (de)\n" +
          "Italian (it).")
  public String Language() {
    return language;
  }

  @DesignerProperty(editorType = PropertyTypeConstants.PROPERTY_TYPE_STRING, defaultValue = "en")
  @SimpleProperty
  public void Language(String language) {
    this.language = language;
  }

  @SimpleFunction(description = "Converts text to speech. After the sound file is generated, \"AudioIsReady\" event is triggered.")
  public void Synthesize(final String text) {
    getCredentials(new Runnable() {
      @Override
      public void run()
      {
        AsynchUtil.runAsynchronously(new Runnable() {
          @Override
          public void run() {
            try {
              AmazonPollyClient client = new AmazonPollyPresigningClient(new StaticCredentialsProvider(new BasicAWSCredentials(awsAccessKeyId, awsSecretKey)));
              client.setRegion(Region.getRegion(region));

              SynthesizeSpeechRequest req = new SynthesizeSpeechRequest()
                      .withVoiceId(voicesByLang.get(language))
                      .withOutputFormat(OutputFormat.Mp3)
                      .withText(text);

              SynthesizeSpeechResult res = client.synthesizeSpeech(req);

              final String filePath = saveAudio(null, res.getAudioStream(), res.getContentType());

              activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  AudioIsReady("", filePath);
                }
              });
            }
            catch (final AmazonServiceException e) {
              activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                  AudioIsReady(e.toString(), "");
                }
              });
            }
            catch (Exception e) {
              StringWriter sw = new StringWriter();
              PrintWriter pw = new PrintWriter(sw);
              e.printStackTrace(pw);
              pw.flush();
              form.dispatchErrorOccurredEvent(AWSPolly.this, "Synthesize",
                      ErrorMessages.ERROR_EXTENSION_ERROR, 1, e.toString(), sw.toString());
            }
          }
        });
      }
    });
  }

  @SimpleEvent(description = "Triggered when Amazon Polly returned the " +
          "audio file. If an error occurs, error is returned.")
  public void AudioIsReady(String error, String audio) {
    EventDispatcher.dispatchEvent(this, "AudioIsReady", error, audio);
  }

  private static String saveAudio(String responseFileName, InputStream audioStream, String responseType) throws IOException {
    File file = createFile(responseFileName, responseType);

    BufferedOutputStream out = null;
    try {
      out = new BufferedOutputStream(new FileOutputStream(file), 0x1000);
      IOUtils.copy(audioStream, out);
    }
    finally {
      try
      {
        audioStream.close();
      }
      finally
      {
      }
      if (out != null)
        try
        {
          out.close();
        }
        finally
        {
        }
    }
    return file.getAbsolutePath();
  }

  private static File createFile(String fileName, String responseType)
          throws IOException, FileUtil.FileException {
    // If a fileName was specified, use it.
    if (!TextUtils.isEmpty(fileName)) {
      return FileUtil.getExternalFile(fileName);
    }

    // Otherwise, try to determine an appropriate file extension from the responseType.
    // The response type could contain extra information that we don't need. For example, it might
    // be "text/html; charset=ISO-8859-1". We just want to look at the part before the semicolon.
    int indexOfSemicolon = responseType.indexOf(';');
    if (indexOfSemicolon != -1) {
      responseType = responseType.substring(0, indexOfSemicolon);
    }
    String extension = mimeTypeToExtension.get(responseType);
    if (extension == null) {
      extension = "tmp";
    }
    return FileUtil.getDownloadFile(extension);
  }

  static {
    mimeTypeToExtension = Maps.newHashMap();
    mimeTypeToExtension.put("application/pdf", "pdf");
    mimeTypeToExtension.put("application/zip", "zip");
    mimeTypeToExtension.put("audio/mpeg", "mpeg");
    mimeTypeToExtension.put("audio/mp3", "mp3");
    mimeTypeToExtension.put("audio/mp4", "mp4");
    mimeTypeToExtension.put("image/gif", "gif");
    mimeTypeToExtension.put("image/jpeg", "jpg");
    mimeTypeToExtension.put("image/png", "png");
    mimeTypeToExtension.put("image/tiff", "tiff");
    mimeTypeToExtension.put("text/plain", "txt");
    mimeTypeToExtension.put("text/html", "html");
    mimeTypeToExtension.put("text/xml", "xml");

    voicesByLang = new HashMap<String, String>();
    voicesByLang.put("en", "Joanna");
    voicesByLang.put("es", "Penelope");
    voicesByLang.put("tr", "Filiz");
    voicesByLang.put("fr", "Lea");
    voicesByLang.put("de", "Vicki");
    voicesByLang.put("it", "Carla");
  }
}
